﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// ColorImageAlpha1.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ColorImageAlpha1TYPE        130
#define IDD_CONSTANT                    310
#define IDC_EDIT_CONSTANT               1000
#define ID_32771                        32771
#define ID                              32772
#define IDM_EQUAL_IMAGE                 32773
#define ID_32774                        32774
#define IDM_GRAY_SCALE                  32775
#define ID_32776                        32776
#define IDM_ADD_IMAGE                   32777
#define ID_32778                        32778
#define IDM_REVERSE_IMAGE               32779
#define ID_32780                        32780
#define IDM_BW_IMAGE                    32781
#define ID_32782                        32782
#define IDM_RGB_BW                      32783
#define ID_32784                        32784
#define IDM_GAMMA_IMAGE                 32785
#define ID_HSI32786                     32786
#define IDM_CHANGE_SATUR                32787
#define ID_HSI32788                     32788
#define IDM_PICK_ORANGE                 32789

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32790
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
